

void f2(int x) {
	if (x > 10)
		x += 10;
	else
		x -= 10;
}
